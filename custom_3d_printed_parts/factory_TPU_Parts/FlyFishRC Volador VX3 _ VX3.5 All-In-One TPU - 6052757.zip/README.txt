FlyFishRC Volador VX3 / VX3.5 All-In-One TPU by FlyFishRC on Thingiverse: https://www.thingiverse.com/thing:6052757

Summary:
FlyFishRC Volador VX3/VX3.5 TPU Set