30.5 mm Receiver Holder (e.g. EP1, FlyFishRC VX3 style) by lasa01 on Thingiverse: https://www.thingiverse.com/thing:7046298

Summary:
Modified FlyFishRC VX3 Receiver Holder STL, with 30.5 mm hole spacing instead of 20 mm, and 3 mm holes instead of 2 mm. Print in TPU. Fits Happymodel EP1 receiver for example.