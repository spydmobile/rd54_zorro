AOS 3.5 ELRS antenna mount (Happymodel EP1) by nuggetfpv on Thingiverse: https://www.thingiverse.com/thing:6327853

Summary:
Happymodel EP1 2.4g ELRS antenna mount for the AOS 3.5 frame. 4mm height at the standoff mounts, gives enough clearance for the VTX antenna mount.Print with TPU, 25% infill, 5 perimeters.Bend the two halves of the mount, then bend the antenna wires towards the mount. Insert both wires into the mount, then place the T joint of the antenna into the mount. 